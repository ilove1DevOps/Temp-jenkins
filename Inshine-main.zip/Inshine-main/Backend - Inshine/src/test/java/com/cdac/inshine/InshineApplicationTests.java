package com.cdac.inshine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InshineApplicationTests {

	@Test
	void contextLoads() {
	}

}
