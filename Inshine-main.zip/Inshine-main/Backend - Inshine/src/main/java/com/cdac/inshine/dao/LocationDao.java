package com.cdac.inshine.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.inshine.model.LocationEntity;


public interface LocationDao extends JpaRepository<LocationEntity, Integer>{

}


